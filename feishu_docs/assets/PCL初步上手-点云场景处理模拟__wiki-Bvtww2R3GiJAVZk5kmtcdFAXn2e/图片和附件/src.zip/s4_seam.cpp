﻿// ============================================================
// 阶段 4：缝线提取
// 工业对应：在工件上找到批缝/毛刺所在的待磨边缘。
//   真实项目里，缝隙检测常用三种手段：
//     a) 线激光轮廓仪直接扫出 V 形缝（工业主流）
//     b) 曲率/深度突变分析
//     c) CAD 模型的缝线投影到实际工件点云上
//   demo 简化：用"边界点"代表缝 —— 边界=工件点云的轮廓边缘，
//   再对边界点聚类，取最长的一段当作待磨的"一条缝"。
// ============================================================
#include "common.h"
#include <pcl/features/normal_3d.h>
#include <pcl/features/boundary.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/search/kdtree.h>
#include <pcl/common/io.h>

namespace gd {

int runSeam() {
  banner(4, "缝线提取：工件边界点 = 待磨缝");

  auto workpiece = std::make_shared<Cloud>();
  if (!loadPCD(outputDir() + "03_workpiece.pcd", workpiece)) return 1;
  printCloudInfo("目标工件", workpiece);

  // ---------- 4.1 先估法向量（边界估计的输入） ----------
  auto normals = std::make_shared<pcl::PointCloud<pcl::Normal>>();
  pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
  ne.setInputCloud(workpiece);
  ne.setSearchMethod(std::make_shared<pcl::search::KdTree<pcl::PointXYZ>>());
  ne.setRadiusSearch(0.02f);  // 4 倍体素：边界点附近点稀疏，半径略放大
  ne.compute(*normals);

  // ---------- 4.2 边界点估计 ----------
  // 原理：对每个点，把邻域点投影到局部平面；若邻域的"方向张角"超过阈值，
  //       说明该点一侧有点、一侧没点 —— 它在边缘上。
  pcl::PointCloud<pcl::Boundary> boundaries;
  pcl::BoundaryEstimation<pcl::PointXYZ, pcl::Normal, pcl::Boundary> be;
  be.setInputCloud(workpiece);
  be.setInputNormals(normals);
  be.setSearchMethod(std::make_shared<pcl::search::KdTree<pcl::PointXYZ>>());
  be.setRadiusSearch(0.015f);       // 3 倍体素
  be.setAngleThreshold(kPi / 2.0f); // 张角阈值：调小→边界点变多，调大→变少
  be.compute(boundaries);

  auto seam_all = std::make_shared<Cloud>();
  for (size_t i = 0; i < workpiece->size(); ++i)
    if (boundaries.points[i].boundary_point)
      seam_all->push_back(workpiece->points[i]);

  std::cout << "  边界点: " << seam_all->size() << " / " << workpiece->size()
            << " (" << (100.0 * seam_all->size() / workpiece->size()) << "%)" << std::endl;
  if (seam_all->empty()) {
    std::cerr << "  [错误] 没有提取到边界点：试着调小角度阈值或加大搜索半径" << std::endl;
    return 1;
  }
  savePCD(outputDir() + "05_seam_raw.pcd", seam_all);

  // ---------- 4.3 边界点再聚类，取最长一段作为"一条缝" ----------
  // 工业含义：一个铸件往往有多条批缝，本 demo 只处理最长的一条。
  // 注意：深度相机的遮挡空洞也会产生"伪边界"，聚类+取最长段能滤掉大部分。
  std::vector<pcl::PointIndices> segs;
  pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
  ec.setClusterTolerance(0.01f);  // 1cm：边界点是沿轮廓连续分布的
  ec.setMinClusterSize(20);
  ec.setMaxClusterSize(500000);
  ec.setSearchMethod(std::make_shared<pcl::search::KdTree<pcl::PointXYZ>>());
  ec.setInputCloud(seam_all);
  ec.extract(segs);

  if (segs.empty()) {
    std::cerr << "  [错误] 边界点没能连成段，试着增大聚类容差" << std::endl;
    return 1;
  }
  size_t best = 0;
  for (size_t i = 1; i < segs.size(); ++i)
    if (segs[i].indices.size() > segs[best].indices.size()) best = i;

  auto seam = std::make_shared<Cloud>();
  pcl::copyPointCloud(*seam_all, segs[best].indices, *seam);
  std::cout << "  边界共连成 " << segs.size() << " 段, 取最长一段作为缝: " << seam->size() << " 点" << std::endl;
  return savePCD(outputDir() + "06_seam.pcd", seam) ? 0 : 1;
}

} // namespace gd
