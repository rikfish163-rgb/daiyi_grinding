﻿// ============================================================
// 阶段 3：工件定位（项目核心）
// 工业对应：把"CAD 模型"配准到扫描点云上，求出工件的实际位姿。
//   真实打磨项目里，工件是毛坯、每件摆放都不同，示教轨迹必然失效；
//   这一步求出的 4x4 矩阵就是"工件坐标系相对相机坐标系"的变换，
//   再乘上手眼标定矩阵即可换算到机器人基坐标系 —— 整条流水线的枢纽。
// 流程：对每个候选簇 —— 法向量 → FPFH 特征 → SAC-IA 粗配准 → ICP 精配准
//       配准得分最好的簇 = 识别出的目标工件
// ============================================================
#include "common.h"
#include <pcl/features/normal_3d.h>
#include <pcl/features/fpfh.h>
#include <pcl/registration/ia_ransac.h>
#include <pcl/registration/icp.h>
#include <pcl/common/transforms.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/search/kdtree.h>
#include <fstream>
#include <iomanip>
#include <limits>
#include <cstdio>

namespace gd {

using FeatureCloud = pcl::PointCloud<pcl::FPFHSignature33>;

// ---------- 工具函数：估计法向量 ----------
// radius 是邻域搜索半径，经验值取 3~4 倍体素边长（本 demo 体素 5mm）
static void estimateNormals(const CloudPtr& cloud, float radius,
                            pcl::PointCloud<pcl::Normal>& out) {
  pcl::NormalEstimation<pcl::PointXYZ, pcl::Normal> ne;
  ne.setInputCloud(cloud);
  ne.setSearchMethod(std::make_shared<pcl::search::KdTree<pcl::PointXYZ>>());
  ne.setRadiusSearch(radius);
  ne.compute(out);
}

// ---------- 工具函数：FPFH 特征 ----------
// 原理：把每个点邻域内的几何关系（点对的角度/距离统计）编码成 33 维直方图，
//       相当于该点的"几何指纹"。不同位姿下同一物体对应点的指纹一致，
//       配准就是靠指纹找"同名点"。
static void computeFPFH(const CloudPtr& cloud,
                        const pcl::PointCloud<pcl::Normal>::Ptr& normals,
                        float radius, FeatureCloud::Ptr out) {
  pcl::FPFHEstimation<pcl::PointXYZ, pcl::Normal, pcl::FPFHSignature33> fpfh;
  fpfh.setInputCloud(cloud);
  fpfh.setInputNormals(normals);
  fpfh.setSearchMethod(std::make_shared<pcl::search::KdTree<pcl::PointXYZ>>());
  fpfh.setRadiusSearch(radius);  // 经验值：法向半径的 1.5 倍左右
  fpfh.compute(*out);
}

// ---------- 对单个候选簇执行 粗配准 + 精配准 ----------
// 返回：是否成功；fitness = 配准后模型点到簇的平均最近邻距离(米,越小越好)
//       T = 模型坐标系 → 场景(相机)坐标系 的 4x4 刚体变换
static bool alignOne(const CloudPtr& model, const FeatureCloud::Ptr& model_feat,
                     const CloudPtr& cand, float& fitness, Eigen::Matrix4f& T) {
  if (cand->size() < 100) return false;  // 点太少没有配准意义

  // 候选簇的法向量与 FPFH 特征
  auto cand_normals = std::make_shared<pcl::PointCloud<pcl::Normal>>();
  estimateNormals(cand, 0.02f, *cand_normals);
  auto cand_feat = std::make_shared<FeatureCloud>();
  computeFPFH(cand, cand_normals, 0.025f, cand_feat);

  // ---------- SAC-IA 粗配准 ----------
  // 原理：在模型和候选簇的特征里找"几何指纹相似"的点对，用 RANSAC 挑出
  //       一组空间关系一致的对应点求解初始位姿。
  // 为什么要这一步：ICP 是局部算法，初值差了就会卡在错误位置（局部极小）。
  pcl::SampleConsensusInitialAlignment<pcl::PointXYZ, pcl::PointXYZ, pcl::FPFHSignature33> sac_ia;
  sac_ia.setInputSource(model);
  sac_ia.setSourceFeatures(model_feat);
  sac_ia.setInputTarget(cand);
  sac_ia.setTargetFeatures(cand_feat);
  sac_ia.setMaxCorrespondenceDistance(0.05f);  // 指纹匹配时的距离容限（粗）
  sac_ia.setMinSampleDistance(0.01f);          // 采样点间最小间距
  sac_ia.setRANSACIterations(1000);            // RANSAC 外层迭代次数
  auto coarse = std::make_shared<Cloud>();
  sac_ia.align(*coarse);
  if (!sac_ia.hasConverged()) return false;
  Eigen::Matrix4f T_coarse = sac_ia.getFinalTransformation();

  // ---------- ICP 精配准（两级，由粗到细 —— 工业常用手法） ----------
  // 原理：迭代"最近点配对 → 求最小二乘最优刚体变换"直到收敛。
  // 第一级容差放大（3cm）先把姿态拉正，第二级收紧（1cm）追求贴合精度。
  pcl::IterativeClosestPoint<pcl::PointXYZ, pcl::PointXYZ> icp;
  icp.setInputSource(model);   // 要移动的：模型
  icp.setInputTarget(cand);    // 不动的：扫描到的工件
  icp.setMaximumIterations(100);
  icp.setTransformationEpsilon(1e-8);   // 变换变化小于该值视为收敛
  icp.setMaxCorrespondenceDistance(0.03f);
  auto fine = std::make_shared<Cloud>();
  icp.align(*fine, T_coarse);                  // 用粗配准结果作初值
  if (!icp.hasConverged()) return false;
  icp.setMaxCorrespondenceDistance(0.01f);
  icp.setMaximumIterations(100);
  icp.align(*fine, icp.getFinalTransformation());
  if (!icp.hasConverged()) return false;

  fitness = static_cast<float>(icp.getFitnessScore());
  T       = icp.getFinalTransformation();
  return true;
}

int runLocate() {
  banner(3, "定位：模型配准求工件位姿");

  // ---------- 3.1 读取"CAD 模型" ----------
  // model.pcd 带 rgba 字段，先按 XYZRGBA 读入再转成 XYZ（丢弃颜色）
  auto model_rgba = std::make_shared<pcl::PointCloud<pcl::PointXYZRGBA>>();
  if (pcl::io::loadPCDFile<pcl::PointXYZRGBA>(dataDir() + "model.pcd", *model_rgba) < 0) {
    std::cerr << "  [错误] 无法读取模型文件 " << dataDir() << "model.pcd" << std::endl;
    return 1;
  }
  auto model = std::make_shared<Cloud>();
  pcl::copyPointCloud(*model_rgba, *model);
  printCloudInfo("CAD 模型(原始)", model);

  // 模型与场景必须同密度：特征统计和最近邻距离才可比。同样 5mm 体素。
  auto model_ds = std::make_shared<Cloud>();
  pcl::VoxelGrid<pcl::PointXYZ> voxel;
  voxel.setInputCloud(model);
  voxel.setLeafSize(0.005f, 0.005f, 0.005f);
  voxel.filter(*model_ds);
  std::cout << "  模型降采样后: " << model_ds->size() << " 点" << std::endl;

  // 模型的特征只算一次，循环里反复用
  auto model_normals = std::make_shared<pcl::PointCloud<pcl::Normal>>();
  estimateNormals(model_ds, 0.02f, *model_normals);
  auto model_feat = std::make_shared<FeatureCloud>();
  computeFPFH(model_ds, model_normals, 0.025f, model_feat);

  // ---------- 3.2 逐个候选簇尝试配准，按得分识别目标工件 ----------
  float best_fitness = std::numeric_limits<float>::max();
  CloudPtr best_cluster;
  Eigen::Matrix4f best_T = Eigen::Matrix4f::Identity();
  int best_idx = -1;

  std::cout << "\n  对每个候选簇尝试配准:" << std::endl;
  for (int i = 0;; ++i) {
    char name[64];
    snprintf(name, sizeof(name), "03_cluster_%d.pcd", i);
    std::string path = outputDir() + name;
    if (!std::filesystem::exists(path)) break;   // 候选遍历完

    auto cand = std::make_shared<Cloud>();
    if (!loadPCD(path, cand)) continue;
    float fitness = -1.0f;
    Eigen::Matrix4f T;
    bool ok = alignOne(model_ds, model_feat, cand, fitness, T);
    if (ok) {
      std::cout << "    簇 " << i << ": 配准得分 " << fitness
                << " m (平均最近邻距离，越小=越像目标工件)" << std::endl;
      if (fitness < best_fitness) {
        best_fitness = fitness;
        best_T = T;
        best_idx = i;
        best_cluster = cand;
      }
    } else {
      std::cout << "    簇 " << i << ": 配准失败" << std::endl;
    }
  }

  if (best_idx < 0) {
    std::cerr << "  [错误] 所有候选簇配准都失败，检查模型与场景是否为同一物体。" << std::endl;
    return 1;
  }
  std::cout << "\n  识别结果: 簇 " << best_idx << " 是目标工件, 得分 " << best_fitness << " m" << std::endl;

  // 识别出的工件单独存档（阶段 4/5 和可视化都要用）
  savePCD(outputDir() + "03_workpiece.pcd", best_cluster);

  // 把模型按最优变换搬到场景里，直观验证配准质量（应与工件严丝合缝）
  auto aligned = std::make_shared<Cloud>();
  pcl::transformPointCloud(*model_ds, *aligned, best_T);
  savePCD(outputDir() + "04_model_aligned.pcd", aligned);

  // ---------- 3.3 输出位姿结果 ----------
  // T 的含义：模型(工件)坐标系中的一个点 p_model，在相机坐标系下位于 T*p_model。
  // 真实项目链路：p_base = T_base_tool * T_tool_flange * T_flange_cam * (T * p_model)
  // 其中 T_flange_cam 即手眼标定矩阵 —— 见 README。
  Eigen::Matrix3f R = best_T.block<3, 3>(0, 0);
  Eigen::Vector3f t = best_T.block<3, 1>(0, 3);
  Eigen::Quaternionf q(R);
  q.normalize();

  std::ofstream f(outputDir() + "locate_result.txt");
  f << std::fixed << std::setprecision(6);
  f << "# 工件位姿定位结果 (grinding_demo 阶段3)\n";
  f << "# 变换: 模型坐标系 -> 相机(场景)坐标系\n";
  f << "best_cluster: " << best_idx << "\n";
  f << "fitness_m: " << best_fitness << "\n";
  f << "# 4x4 齐次变换矩阵 (行优先):\n";
  for (int r = 0; r < 4; ++r) {
    for (int c = 0; c < 4; ++c) f << best_T(r, c) << (c < 3 ? " " : "\n");
  }
  f << "# 平移 (m): " << t.x() << " " << t.y() << " " << t.z() << "\n";
  f << "# 四元数 xyzw: " << q.x() << " " << q.y() << " " << q.z() << " " << q.w() << "\n";
  f.close();

  std::cout << "  工件位姿: 平移 (" << t.x() << ", " << t.y() << ", " << t.z() << ") m" << std::endl;
  std::cout << "  详细矩阵已写入 output/locate_result.txt" << std::endl;
  std::cout << "  验证方法: pcl_viewer 同时打开 03_workpiece.pcd 和 04_model_aligned.pcd," << std::endl;
  std::cout << "            蓝色模型应严丝合缝地贴在绿色工件上" << std::endl;
  return 0;
}

} // namespace gd
