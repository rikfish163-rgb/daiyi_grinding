﻿// ============================================================
// 阶段 6：总览可视化
// 交互窗口里检查整条流水线的每一步成果：
//   灰 = 预处理后的场景     绿 = 识别出的工件
//   蓝 = 配准到场景的CAD    红 = 缝线
//   黄 = 打磨路径点         白色短线 = 工具轴(姿态)
// 没跑完全部阶段也能看：缺哪个文件就自动跳过哪个。
// ============================================================
#include "common.h"
#include <pcl/visualization/pcl_visualizer.h>
#include <boost/thread/thread.hpp>

namespace gd {

int runView() {
  banner(6, "总览可视化（关闭窗口后程序退出）");

  auto scene = std::make_shared<Cloud>();
  bool has_scene = loadPCD(outputDir() + "01_scene_filtered.pcd", scene);
  auto work = std::make_shared<Cloud>();
  bool has_work = loadPCD(outputDir() + "03_workpiece.pcd", work);
  auto model = std::make_shared<Cloud>();
  bool has_model = loadPCD(outputDir() + "04_model_aligned.pcd", model);
  auto seam = std::make_shared<Cloud>();
  bool has_seam = loadPCD(outputDir() + "06_seam.pcd", seam);

  pcl::PointCloud<pcl::PointNormal>::Ptr path(new pcl::PointCloud<pcl::PointNormal>);
  bool has_path = pcl::io::loadPCDFile<pcl::PointNormal>(outputDir() + "07_path_points.pcd", *path) >= 0;

  if (!has_scene && !has_work) {
    std::cerr << "  [提示] output/ 下还没有任何结果，请先运行阶段 1" << std::endl;
    return 1;
  }

  auto viewer(new pcl::visualization::PCLVisualizer("grinding_demo - pipeline overview"));
  viewer->setBackgroundColor(0.05f, 0.05f, 0.08f);
  viewer->addCoordinateSystem(0.1f);  // 相机坐标系: 红x 绿y 蓝z
  // 可视化窗口内嵌字体不含中文，图例用英文
  viewer->addText("gray=scene  green=workpiece  blue=CAD model  red=seam  yellow=path  white=tool axis",
                  10, 10, 14, 1.0, 1.0, 1.0, "legend");

  auto addCloud = [&](const CloudPtr& c, const std::string& id, int r, int g, int b, int size) {
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> color(c, r, g, b);
    viewer->addPointCloud<pcl::PointXYZ>(c, color, id);
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, size, id);
  };

  if (has_scene) addCloud(scene, "scene",     140, 140, 140, 1);
  if (has_work)  addCloud(work,  "workpiece",   0, 200,   0, 2);
  if (has_model) addCloud(model, "model",       0, 120, 255, 2);
  if (has_seam)  addCloud(seam,  "seam",      255,  40,  40, 4);
  if (has_path) {
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointNormal> pcolor(path, 255, 220, 0);
    viewer->addPointCloud<pcl::PointNormal>(path, pcolor, "path");
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 6, "path");
    // 把每个路径点存的"工具轴"画成短线，直观检查姿态是否平滑、朝向是否合理
    viewer->addPointCloudNormals<pcl::PointNormal>(path, 1, 0.03f, "tool_axes");
  }

  std::cout << "  可视化窗口已打开，按 q 关闭。拖动旋转 / 滚轮缩放 / shift+拖动平移" << std::endl;
  while (!viewer->wasStopped()) {
    viewer->spinOnce(100);
    boost::this_thread::sleep(boost::posix_time::microseconds(1000));
  }
  return 0;
}

} // namespace gd
