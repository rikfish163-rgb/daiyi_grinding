﻿// ============================================================
// 阶段 1：预处理
// 工业对应：相机原始数据的清理 —— 机器人自动化打磨的第一步
// 流程：读场景 → 直通滤波(限定工作空间) → 体素降采样 → 统计滤波去噪
// ============================================================
#include "common.h"
#include <pcl/filters/passthrough.h>
#include <pcl/filters/voxel_grid.h>
#include <pcl/filters/statistical_outlier_removal.h>

namespace gd {

int runPreprocess() {
  banner(1, "预处理：裁剪工作空间 / 降采样 / 去噪");

  // ---------- 1.1 读取"相机拍到的"工位场景 ----------
  auto scene = std::make_shared<Cloud>();
  if (!loadPCD(dataDir() + "scene.pcd", scene)) return 1;
  printCloudInfo("原始场景", scene);
  std::cout << "  有序点云: " << (scene->isOrganized() ? "是" : "否")
            << "  (width=" << scene->width << ", height=" << scene->height << ")"
            << " —— 640x480 说明它来自深度相机的一帧" << std::endl;

  // ---------- 1.2 直通滤波：只保留工作空间内的点 ----------
  // 工业含义：相机视野里常有传送带、围栏、背景杂物，
  // 按深度方向裁出"机器人可达的工作空间"，是最简单有效的 ROI 裁剪。
  CloudPtr workspace(new Cloud);
  pcl::PassThrough<pcl::PointXYZ> pass;
  pass.setInputCloud(scene);
  pass.setFilterFieldName("z");      // 对 z(深度)方向滤波，也可以用 "x"/"y"
  // 注意: 本数据来自 Kinect, 相机光轴朝向使得深度为负值(见上方 z 范围)。
  // 教训: 任何滤波之前先看包围盒, 区间要与数据实际范围匹配!
  pass.setFilterLimits(-2.0f, -0.5f);  // 单位:米, 保留 z 在 [-2.0, -0.5] 的点
  pass.filter(*workspace);
  std::cout << "  直通滤波后: " << workspace->size() << " 点" << std::endl;

  // ---------- 1.3 体素降采样 ----------
  // 原理：空间划成 5mm 的小方块，每个方块内所有点用其重心代替。
  // 工业含义：深度图点非常密，法向/特征/配准都很慢；
  // 5mm 档位对磨削轨迹够用（磨削余量通常 0.2~1mm，定位精度要求 1~2mm）。
  CloudPtr down(new Cloud);
  pcl::VoxelGrid<pcl::PointXYZ> voxel;
  voxel.setInputCloud(workspace);
  voxel.setLeafSize(0.005f, 0.005f, 0.005f);  // 体素边长 5mm，调大→更快更糙，调小→更慢更细
  voxel.filter(*down);
  std::cout << "  体素降采样后: " << down->size() << " 点" << std::endl;

  // ---------- 1.4 统计滤波：去掉悬浮的离群噪点 ----------
  // 原理：对每个点统计其 50 个近邻的平均距离；若该点偏离全局平均超过
  //       1.0 倍标准差，判定为噪点删除。
  // 工业含义：金属反光、飞溅产生的孤立噪声点，会干扰配准和分割。
  CloudPtr clean(new Cloud);
  pcl::StatisticalOutlierRemoval<pcl::PointXYZ> sor;
  sor.setInputCloud(down);
  sor.setMeanK(50);             // 近邻点数
  sor.setStddevMulThresh(1.0);  // 标准差倍数阈值，调小→删得更狠
  sor.filter(*clean);
  std::cout << "  统计滤波后: " << clean->size() << " 点" << std::endl;

  printCloudInfo("预处理结果", clean);
  return savePCD(outputDir() + "01_scene_filtered.pcd", clean) ? 0 : 1;
}

} // namespace gd
