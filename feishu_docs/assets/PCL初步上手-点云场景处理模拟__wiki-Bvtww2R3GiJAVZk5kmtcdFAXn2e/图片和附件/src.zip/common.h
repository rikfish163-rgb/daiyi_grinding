﻿#pragma once
// ============================================================
// common.h —— grinding_demo 公共工具
// 工件打磨点云处理流程练手 demo
// 约定：所有坐标单位为"米"（与 PCL 官方场景数据一致）
// ============================================================
#include <iostream>
#include <string>
#include <vector>
#include <filesystem>
#include <pcl/point_types.h>
#include <pcl/point_cloud.h>
#include <pcl/io/pcd_io.h>
#include <pcl/common/common.h>   // getMinMax3D

namespace gd {

// 统一使用 XYZ 点类型：颜色信息不参与本 demo 的算法，读取时一律丢弃
using Cloud    = pcl::PointCloud<pcl::PointXYZ>;
using CloudPtr = Cloud::Ptr;

const float kPi = 3.14159265358979f;

// ---------- 目录约定 ----------
// 程序总是从 grinding_demo 目录运行：
//   data/   放输入点云（scene.pcd 工位场景, model.pcd 工件CAD模型）
//   output/ 放各阶段的中间结果与最终轨迹
inline const std::string& dataDir()   { static const std::string d = "data/";   return d; }
inline const std::string& outputDir() { static const std::string d = "output/"; return d; }

inline void ensureOutputDir() {
  std::filesystem::create_directories(outputDir());
}

// ---------- 带错误提示的读写封装（PointXYZ 专用） ----------
inline bool loadPCD(const std::string& path, CloudPtr cloud) {
  if (pcl::io::loadPCDFile<pcl::PointXYZ>(path, *cloud) < 0) {
    std::cerr << "  [错误] 无法读取点云文件: " << path << std::endl;
    return false;
  }
  return true;
}

inline bool savePCD(const std::string& path, const CloudPtr cloud) {
  if (pcl::io::savePCDFileBinary(path, *cloud) < 0) {
    std::cerr << "  [错误] 无法写出点云文件: " << path << std::endl;
    return false;
  }
  std::cout << "  已保存: " << path << "  (" << cloud->size() << " 点)" << std::endl;
  return true;
}

// 打印点云基本信息：点数 + 三维包围盒
inline void printCloudInfo(const std::string& name, const CloudPtr cloud) {
  if (cloud->empty()) {
    std::cout << "  [" << name << "] 0 点" << std::endl;
    return;
  }
  pcl::PointXYZ mn, mx;
  pcl::getMinMax3D(*cloud, mn, mx);
  std::cout << "  [" << name << "] " << cloud->size() << " 点, "
            << "范围 x[" << mn.x << ", " << mx.x << "] "
            << "y[" << mn.y << ", " << mx.y << "] "
            << "z[" << mn.z << ", " << mx.z << "] (m)" << std::endl;
}

// 阶段标题
inline void banner(int step, const std::string& title) {
  std::cout << "\n========== 阶段 " << step << " : " << title << " ==========" << std::endl;
}

} // namespace gd
