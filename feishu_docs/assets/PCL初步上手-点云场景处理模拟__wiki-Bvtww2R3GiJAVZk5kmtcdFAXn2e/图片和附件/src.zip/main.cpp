﻿// ============================================================
// grinding_demo —— 工件打磨点云处理流程练手 demo
//
// 流水线：采集场景 → 预处理 → 分割找工件 → 模型配准定位
//         → 缝线提取 → 打磨路径生成
//
// 用法: grinding_demo.exe <preprocess|segment|locate|seam|path|view|all>
// 注意: 必须在 grinding_demo 目录下运行（读取 data/，写出 output/）
// ============================================================
#include "common.h"
#include <string>
#ifdef _WIN32
#include <windows.h>
#endif

namespace gd {
int runPreprocess();
int runSegment();
int runLocate();
int runSeam();
int runPath();
int runView();
} // namespace gd

static int usage() {
  std::cout <<
    "grinding_demo —— 工件打磨点云处理流程练手 demo\n"
    "场景: 相机拍到工位桌面上的工件, 自动求出工件位姿并生成待磨缝的打磨轨迹\n\n"
    "用法: grinding_demo.exe <阶段>\n"
    "  preprocess  阶段1: 预处理 —— 裁剪工作空间/降采样/去噪\n"
    "  segment     阶段2: 分割   —— RANSAC剔桌面 + 欧式聚类找工件候选\n"
    "  locate      阶段3: 定位   —— 模型配准识别工件并输出位姿矩阵(核心)\n"
    "  seam        阶段4: 缝线   —— 提取工件边界点作为待磨缝\n"
    "  path        阶段5: 轨迹   —— 重采样+法向+工具位姿, 输出 trajectory.csv\n"
    "  view        阶段6: 可视化 —— 总览所有中间结果\n"
    "  all         依次执行阶段 1~5, 最后弹出可视化窗口\n\n"
    "示例:\n"
    "  grinding_demo.exe all\n"
    "  pcl_viewer output/01_scene_filtered.pcd   (查看任一中间结果)\n";
  return 1;
}

int main(int argc, char** argv) {
#ifdef _WIN32
  // 程序输出为 UTF-8, 设置控制台代码页保证 cmd/PowerShell 下中文正常显示
  SetConsoleOutputCP(CP_UTF8);
#endif
  if (argc < 2) return usage();
  gd::ensureOutputDir();

  const std::string cmd = argv[1];
  if (cmd == "preprocess") return gd::runPreprocess();
  if (cmd == "segment")    return gd::runSegment();
  if (cmd == "locate")     return gd::runLocate();
  if (cmd == "seam")       return gd::runSeam();
  if (cmd == "path")       return gd::runPath();
  if (cmd == "view")       return gd::runView();
  if (cmd == "all") {
    if (gd::runPreprocess()) return 1;
    if (gd::runSegment())    return 1;
    if (gd::runLocate())     return 1;
    if (gd::runSeam())       return 1;
    if (gd::runPath())       return 1;
    return gd::runView();
  }
  return usage();
}
