﻿// ============================================================
// 阶段 5：路径生成
// 工业对应：把缝点变成机器人能执行的轨迹 —— 每个路径点必须有
//   "位置 + 工具姿态"，机器人才能走。
// 流程：缝点沿主方向排序 → 每 5mm 等距重采样 → 每点求表面法向 →
//       构造工具位姿（沿进给方向前倾 15°、沿法向抬高 5mm）→ trajectory.csv
// ============================================================
#include "common.h"
#include <pcl/common/centroid.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <Eigen/Dense>
#include <Eigen/Geometry>
#include <fstream>
#include <iomanip>
#include <limits>
#include <algorithm>

namespace gd {

// ---------- 由邻域点集拟合局部平面法向 ----------
// 本质就是"局部 PCA"：邻域点云最扁的方向（最小特征值的特征向量）= 法向。
// 看懂这个函数 = 看懂 PCL 里所有法向估计算法的数学内核。
// orient_ref 传入 (当前点 - 工件质心)，让法向统一指向工件外侧。
static Eigen::Vector3f computeNormal(const std::vector<Eigen::Vector3f>& pts,
                                     const Eigen::Vector3f& orient_ref) {
  Eigen::Vector3f c = Eigen::Vector3f::Zero();
  for (const auto& p : pts) c += p;
  c /= float(pts.size());

  Eigen::Matrix3f cov = Eigen::Matrix3f::Zero();
  for (const auto& p : pts) {
    Eigen::Vector3f d = p - c;
    cov += d * d.transpose();
  }
  // SelfAdjointEigenSolver 的特征值按升序排列：col(0) 是最小特征值的特征向量
  Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> es(cov);
  Eigen::Vector3f n = es.eigenvectors().col(0);
  if (n.dot(orient_ref) < 0) n = -n;  // 定向：从工件内部指向外
  return n;
}

int runPath() {
  banner(5, "路径生成：缝 → 带姿态的打磨轨迹");

  auto seam = std::make_shared<Cloud>();
  if (!loadPCD(outputDir() + "06_seam.pcd", seam)) return 1;
  auto workpiece = std::make_shared<Cloud>();
  if (!loadPCD(outputDir() + "03_workpiece.pcd", workpiece)) return 1;
  printCloudInfo("缝线点", seam);
  if (seam->size() < 2) {
    std::cerr << "  [错误] 缝线点太少，无法生成路径" << std::endl;
    return 1;
  }

  // 工件质心：用于法向定向
  Eigen::Vector4f wc4;
  pcl::compute3DCentroid(*workpiece, wc4);
  Eigen::Vector3f wc = wc4.head<3>();

  // ---------- 5.1 沿缝的走向排序（"散点成线"的轨迹排序问题） ----------
  // 为什么不直接按 PCA 主方向投影排序？—— 缝若不是直线（拐角/弧线），
  // 投影值接近的点会前后跳动，轨迹来回穿插、长度虚增。
  // 这里用工业上常用的"最近邻链"贪心排序：
  //   1) PCA 求缝的主方向, 取主方向最远端的点作链起点（种子在端头, 贪心不易走错）;
  //   2) 每次走向离当前点最近的未访问点, 直到串完所有点。
  // 思考题: 最近邻链是 TSP 的贪心近似, 什么形状的缝它仍会走错? 怎么补救?
  Eigen::Vector4f centroid;
  Eigen::Matrix3f cov;
  pcl::computeMeanAndCovarianceMatrix(*seam, cov, centroid);
  Eigen::SelfAdjointEigenSolver<Eigen::Matrix3f> es(cov);
  Eigen::Vector3f axis = es.eigenvectors().col(2);  // 最大特征值 → 最后一列
  const Eigen::Vector3f c0 = centroid.head<3>();

  std::vector<Eigen::Vector3f> pts(seam->size());
  for (size_t i = 0; i < seam->size(); ++i)
    pts[i] = Eigen::Vector3f(seam->points[i].getVector3fMap());

  size_t start = 0;
  float min_proj = std::numeric_limits<float>::max();
  for (size_t i = 0; i < pts.size(); ++i) {
    float proj = axis.dot(pts[i] - c0);
    if (proj < min_proj) { min_proj = proj; start = i; }
  }

  std::vector<char> used(pts.size(), 0);
  std::vector<size_t> order;
  order.reserve(pts.size());
  size_t cur = start;
  used[cur] = 1;
  order.push_back(cur);
  while (order.size() < pts.size()) {
    size_t best = 0;
    float best_d2 = std::numeric_limits<float>::max();
    for (size_t i = 0; i < pts.size(); ++i) {
      if (used[i]) continue;
      float d2 = (pts[i] - pts[cur]).squaredNorm();
      if (d2 < best_d2) { best_d2 = d2; best = i; }
    }
    cur = best;
    used[cur] = 1;
    order.push_back(cur);
  }

  // ---------- 5.2 等距重采样：沿排序后的折线每 5mm 输出一点 ----------
  // 机器人轨迹点要均匀：太密浪费示教/下发时间，太疏磨痕不均匀。
  const float kStep = 0.005f;  // 步距 5mm（demo 数据下缝长约几十 cm）

  // 先算缝的折线长度，报告用
  double seam_len = 0.0;
  for (size_t k = 1; k < order.size(); ++k) {
    Eigen::Vector3f a(seam->points[order[k - 1]].getVector3fMap());
    Eigen::Vector3f b(seam->points[order[k]].getVector3fMap());
    seam_len += (b - a).norm();
  }

  std::vector<Eigen::Vector3f> samples;
  samples.push_back(Eigen::Vector3f(seam->points[order[0]].getVector3fMap()));
  Eigen::Vector3f cursor = samples.back();  // 折线上已重采样到的位置
  double dist_since_emit = 0.0;             // cursor 距上个采样点的弧长
  for (size_t k = 1; k < order.size(); ++k) {
    Eigen::Vector3f p(seam->points[order[k]].getVector3fMap());
    Eigen::Vector3f seg = p - cursor;
    float d = seg.norm();
    while (d > 1e-9f && dist_since_emit + d >= kStep) {
      float need = float(kStep - dist_since_emit);
      cursor = cursor + seg.normalized() * need;
      samples.push_back(cursor);
      dist_since_emit = 0.0;
      seg = p - cursor;
      d = seg.norm();
    }
    dist_since_emit += d;
    cursor += seg;  // 走到本段终点
  }
  std::cout << "  缝长约 " << seam_len * 1000.0 << " mm, 重采样为 " << samples.size()
            << " 个路径点 (步距 5mm)" << std::endl;

  // ---------- 5.3 每个采样点求表面法向 ----------
  // 关键点：不能直接在"缝线"上算法向 —— 近似共线的点拟合不出平面！
  // 正确做法：回到工件点云里找缝点周围的邻域，由"面上的邻域"拟合法向。
  pcl::KdTreeFLANN<pcl::PointXYZ> kdtree;
  kdtree.setInputCloud(workpiece);
  std::vector<Eigen::Vector3f> normals;
  normals.reserve(samples.size());
  for (const auto& s : samples) {
    pcl::PointXYZ q; q.x = s.x(); q.y = s.y(); q.z = s.z();
    std::vector<int> idx;
    std::vector<float> sq;
    std::vector<Eigen::Vector3f> nbrs;
    if (kdtree.radiusSearch(q, 0.015f, idx, sq) > 2) {
      nbrs.reserve(idx.size());
      for (int id : idx) nbrs.emplace_back(workpiece->points[id].getVector3fMap());
      normals.push_back(computeNormal(nbrs, s - wc));
    } else {
      // 邻域太稀：退化为"背离工件质心"的方向（不精确但可用）
      normals.push_back((s - wc).normalized());
    }
  }

  // ---------- 5.3b 法向沿路径传播定向 ----------
  // 按链的顺序传播符号：相邻路径点的表面法向夹角应小于 90°。
  // 若点积为负，说明法向"翻了"（常发生在遮挡/轮廓切线处的伪边界），
  // 就地翻转保持整条路径法向连续 —— 机器人轨迹姿态一致性的常用处理。
  // 注意：工件拐角处法向本来就转过约 90°（点积≈0），不会被误翻。
  for (size_t k = 1; k < normals.size(); ++k)
    if (normals[k].dot(normals[k - 1]) < 0.0f) normals[k] = -normals[k];

  // ---------- 5.4 构造工具位姿 → 输出 trajectory.csv ----------
  // 工具坐标系约定：z 轴 = 工具轴（磨头进给方向），x 轴 = 进给方向（沿缝）
  // 两个工艺参数：
  //   前倾角：磨头不垂直于表面打，而是沿进给方向倾斜 15°（防止磨轮侧面
  //           擦伤已磨表面，具体角度由工艺决定，改符号=向后倾）
  //   停距  ：工具参考点沿法向抬离表面 5mm，真实打磨由力控压下补偿
  const double kTilt = 15.0 * kPi / 180.0;
  const float kStandoff = 0.005f;

  std::ofstream f(outputDir() + "trajectory.csv");
  f << std::fixed << std::setprecision(6);
  f << "# grinding_demo 打磨轨迹 (单位: 米)\n";
  f << "# 列: id, x,y,z(路径点=缝点+法向*停距), nx,ny,nz(表面法向), tx,ty,tz(工具轴), qx,qy,qz,qw(姿态四元数)\n";

  // 路径点另存为带法向的点云，normal 字段里放的是"工具轴"，供阶段 6 画姿态
  pcl::PointCloud<pcl::PointNormal> path_cloud;

  for (size_t k = 0; k < samples.size(); ++k) {
    Eigen::Vector3f n = normals[k];
    // 进给方向：指向路径上相邻的下一点（末点用前一点）
    Eigen::Vector3f fdir = (k + 1 < samples.size())
        ? (samples[k + 1] - samples[k])
        : (samples[k] - samples[k - 1]);
    if (fdir.norm() < 1e-9f) continue;
    fdir.normalize();

    // 工具轴 = 表面法向绕 (n × f) 轴旋转前倾角 → 等价于"朝进给方向倾倒 15°"
    Eigen::Vector3f rot_axis = n.cross(fdir);
    if (rot_axis.norm() < 1e-6f) rot_axis = Eigen::Vector3f::UnitX();
    else rot_axis.normalize();
    Eigen::Vector3f t = Eigen::AngleAxisf(float(kTilt), rot_axis) * n;

    // 组装正交右手工具坐标系：z=工具轴, x=进给方向(投影到与z垂直), y=z×x
    Eigen::Vector3f x = fdir - fdir.dot(t) * t;
    x.normalize();
    Eigen::Vector3f y = t.cross(x);
    Eigen::Matrix3f R;
    R.col(0) = x; R.col(1) = y; R.col(2) = t;
    Eigen::Quaternionf quat(R);
    quat.normalize();

    Eigen::Vector3f pos = samples[k] + n * kStandoff;

    f << k << ',' << pos.x() << ',' << pos.y() << ',' << pos.z() << ','
      << n.x() << ',' << n.y() << ',' << n.z() << ','
      << t.x() << ',' << t.y() << ',' << t.z() << ','
      << quat.x() << ',' << quat.y() << ',' << quat.z() << ',' << quat.w() << '\n';

    pcl::PointNormal pn;
    pn.x = pos.x(); pn.y = pos.y(); pn.z = pos.z();
    pn.normal_x = t.x(); pn.normal_y = t.y(); pn.normal_z = t.z();
    path_cloud.push_back(pn);
  }
  f.close();
  std::cout << "  已写出: output/trajectory.csv (" << path_cloud.size() << " 个路径点)" << std::endl;
  std::cout << "  每行含义: 位置 + 表面法向 + 工具轴 + 四元数 —— 机器人离线编程的输入雏形" << std::endl;

  if (pcl::io::savePCDFileBinary(outputDir() + "07_path_points.pcd", path_cloud) < 0) return 1;
  std::cout << "  已保存: " << outputDir() << "07_path_points.pcd  (" << path_cloud.size() << " 点)" << std::endl;
  return 0;
}

} // namespace gd
