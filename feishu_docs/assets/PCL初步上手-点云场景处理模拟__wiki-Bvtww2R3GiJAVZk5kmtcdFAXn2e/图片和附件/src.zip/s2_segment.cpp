﻿// ============================================================
// 阶段 2：分割
// 工业对应：从工位场景中找出工件 —— 知道"工件在哪"才能规划轨迹
// 流程：RANSAC 提取桌面平面并剔除 → 欧式聚类得到独立物体 → 保留候选
// ============================================================
#include "common.h"
#include <pcl/segmentation/sac_segmentation.h>
#include <pcl/segmentation/extract_clusters.h>
#include <pcl/filters/extract_indices.h>
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/search/kdtree.h>
#include <pcl/common/io.h>       // copyPointCloud
#include <algorithm>
#include <cstdio>

namespace gd {

int runSegment() {
  banner(2, "分割：剔除桌面 + 聚类找工件候选");

  auto scene = std::make_shared<Cloud>();
  if (!loadPCD(outputDir() + "01_scene_filtered.pcd", scene)) return 1;

  // ---------- 2.1 RANSAC 平面分割：最大的平面 = 桌面 ----------
  // 原理：随机取 3 个点定义一个平面 → 数一数有多少点落在该平面 1cm 薄层内
  //       （内点）→ 重复 1000 次，内点最多的平面胜出。
  // 优点：对噪声和离群点鲁棒，是工业点云里找基准面/定位面的标准手段。
  pcl::ModelCoefficients::Ptr coeffs(new pcl::ModelCoefficients);
  pcl::PointIndices::Ptr inliers(new pcl::PointIndices);
  pcl::SACSegmentation<pcl::PointXYZ> sac;
  sac.setOptimizeCoefficients(true);   // 对结果再做一次最小二乘优化
  sac.setModelType(pcl::SACMODEL_PLANE);
  sac.setMethodType(pcl::SAC_RANSAC);
  sac.setMaxIterations(1000);
  sac.setDistanceThreshold(0.01f);     // 点到平面距离 < 1cm 算内点（桌面并非完美平面）
  sac.setInputCloud(scene);
  sac.segment(*inliers, *coeffs);

  if (inliers->indices.empty()) {
    std::cerr << "  [错误] 未找到平面，请检查阶段 1 的输出。" << std::endl;
    return 1;
  }
  std::cout << "  桌面平面: " << inliers->indices.size() << " 点, 方程 "
            << coeffs->values[0] << "x + " << coeffs->values[1] << "y + "
            << coeffs->values[2] << "z + " << coeffs->values[3] << " = 0" << std::endl;

  // 桌面点单独存一份，可用 pcl_viewer 打开确认分割是否正确
  auto table = std::make_shared<Cloud>();
  pcl::ExtractIndices<pcl::PointXYZ> extract;
  extract.setInputCloud(scene);
  extract.setIndices(inliers);
  extract.filter(*table);
  savePCD(outputDir() + "02_table.pcd", table);

  // ---------- 2.2 剔除桌面，剩下的是"桌面上的物体" ----------
  extract.setNegative(true);  // 反向提取：保留非桌面点
  auto objects = std::make_shared<Cloud>();
  extract.filter(*objects);
  std::cout << "  剔除桌面后剩: " << objects->size() << " 点" << std::endl;

  // ---------- 2.3 欧式聚类：按空间连通性把散点分成独立物体 ----------
  // 原理：以 1.5cm 为"连接半径"建立近邻关系，相互连通的点归为一簇。
  // 工业含义：工件、夹具、料框里的其他物体彼此分离，各自成一簇。
  std::vector<pcl::PointIndices> cluster_indices;
  pcl::EuclideanClusterExtraction<pcl::PointXYZ> ec;
  ec.setClusterTolerance(0.015f);  // 1.5cm：调大→不同物体可能粘连，调小→同一物体可能碎裂
  ec.setMinClusterSize(300);       // 小于 300 点的簇当噪声碎片丢弃
  ec.setMaxClusterSize(200000);
  ec.setSearchMethod(std::make_shared<pcl::search::KdTree<pcl::PointXYZ>>());
  ec.setInputCloud(objects);
  ec.extract(cluster_indices);

  std::cout << "  找到 " << cluster_indices.size() << " 个物体簇（按点数排序）:" << std::endl;

  // 按点数从大到小排序，只保留前 3 个候选
  // 注意：本 demo 不靠"最大簇=工件"这种猜测，而是把候选都留给阶段 3，
  //       用模型配准得分来识别 —— 这才是"基于模型识别"的工业做法。
  std::sort(cluster_indices.begin(), cluster_indices.end(),
            [](const pcl::PointIndices& a, const pcl::PointIndices& b) {
              return a.indices.size() > b.indices.size();
            });

  int saved = 0;
  for (size_t i = 0; i < cluster_indices.size() && saved < 3; ++i, ++saved) {
    auto c = std::make_shared<Cloud>();
    pcl::copyPointCloud(*objects, cluster_indices[i].indices, *c);
    char name[64];
    snprintf(name, sizeof(name), "03_cluster_%d.pcd", saved);
    std::cout << "    簇 " << saved << ": " << c->size() << " 点" << std::endl;
    savePCD(outputDir() + name, c);
  }
  std::cout << "  保留 " << saved << " 个簇作为工件候选，阶段 3 将用模型配准识别目标" << std::endl;
  return saved > 0 ? 0 : 1;
}

} // namespace gd
